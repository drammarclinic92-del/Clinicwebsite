ASNA-CA Website — Phase 2
========================

محتويات ملف الموقع:
- index.html: الصفحة الرئيسية للمنظومة.
- reminder.html: صفحة تطبيق التذكير بالعناية بالأسنان.
- clinic-management.html: صفحة برنامج إدارة عيادات الأسنان.
- assets/styles.css: الهوية البصرية والتصميم المتجاوب.
- assets/script.js: قائمة الهاتف وسنة حقوق النشر.
- assets/asna-ca-logo.png: شعار ASNA-CA المستخدم في الموقع.
- assets/asna-ca-feature.png: صورة ترويجية إضافية إن كانت متوفرة.

طريقة النشر على مستودع Clinicwebsite:
1) ارفع ملف ASNA-CA_Commercial_Platform_Phase2.zip إلى جذر المستودع.
2) ارفع ملف workflow إلى المسار .github/workflows/deploy-site-zip.yml.
3) في GitHub افتح Actions ثم Deploy ASNA-CA Website ZIP to GitHub Pages ثم Run workflow.
4) اترك اسم الملف الافتراضي واضغط Run workflow.
5) انتظر نجاح التنفيذ ثم افتح موقع GitHub Pages.

إذا منع GitHub عملية الدفع من Actions:
Settings > Actions > General > Workflow permissions > Read and write permissions.
تحقق أيضاً من إعداد Pages ليستخدم الفرع main ومجلد الجذر إذا كان ذلك هو إعداد المستودع الحالي.

ملاحظات:
- لم يتم نشر أي شيء إلى GitHub من خلال هذا الملف؛ يلزم رفع الملفات وتشغيل الـ workflow.
- احتفظ بالصور والملفات الأخرى الموجودة مسبقاً في المستودع؛ الـ workflow لا يحذفها.
- لا يحتوي الموقع على تسجيل حسابات أو دفع إلكتروني أو قاعدة بيانات في هذه المرحلة.
- راجع الروابط والمحتوى بعد النشر.
